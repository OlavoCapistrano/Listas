/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano8 {
     /*
    Questão 8
    Faça um programa que leia dois valores, o primeiro servindo de indicador de operação e o segundo correspondendo ao raio de uma circunferência
    Caso o primeiro valor lido seja igual a 1, calcular e imprimir área desta circunferência.
    Se o valor lido for 2, calcular e imprimir o perímetro da circunferência.
    E se o valor lido for diferente destes dois valores; imprimir uma mensagem dizendo que o indicador de operação foi mal fornecido
    
    */
    
public static void main(String[] args) {
    /* Resposta :
    */
    int x;
    float raio, perim, areacirc;
    
    Scanner dados =  new Scanner(System.in); 
    System.out.println("1 -   calcular e imprimir área desta circunferência");
    System.out.println("2 -   calcular e imprimir o perímetro da circunferência");
    System.out.println("Digite O Numero");
    x = dados.nextInt();
    
    System.out.println("Digite o valor do raio");
    raio = dados.nextFloat();
    
    perim = (float) ((2 * 3.14) * raio);
    areacirc = (float) (3.14) * (raio * raio);
    
    switch ( x ){
        case 1 : System.out.println("O Valor da área desta circuferência equivale á"+ areacirc);break;
        case 2 : System.out.println("O Valor do perímetro desta circuferência equivale a" + perim );break;
        
        default : System.out.println("O indicador de operação foi mal fornecido");
    }
    
}


}