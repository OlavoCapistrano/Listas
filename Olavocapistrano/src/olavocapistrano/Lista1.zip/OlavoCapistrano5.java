/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano5 {
/*
    Questão 5 :
     Faça um programa que leia 3 número inteiro os imprima em ordem crescente 
    */    

 public static void main(String[] args) {
    /* Resposta :
    */
   int num1,num2,num3,crescente; 
        Scanner dados =  new Scanner(System.in); 
        System.out.println("Digite o primeiro numero");
        num1 = dados.nextInt();
        System.out.println("Digite o segundo numero");
        num2 = dados.nextInt();
        System.out.println("Digite o terceiro numero");
        num3 = dados.nextInt();
        
     if (num1 < num2 && num1 < num3 && num2 < num3) {
         System.out.println(" A Ordem Crescente é"+num1 );
         System.out.println(+num2);
         System.out.println(+ num3);
     }
     else if (num2 < num1 && num2 < num3 && num1 < num3) {
         System.out.println(" A Ordem Crescente é"+num2 );
         System.out.println(+num1);
         System.out.println(+ num3);
     }
     else if (num3 < num2 && num3 < num1 && num1 < num3) {
         System.out.println(" A Ordem Crescente é"+num3 );
         System.out.println(+num1);
         System.out.println(+ num2);
     }
         
     else if (num1 < num2 && num1 < num3 && num3 < num2) {
         System.out.println(" A Ordem Crescente é"+num1 );
         System.out.println(+num3);
         System.out.println(+ num2);
       }
     else if (num2 < num1 && num2 < num3 && num1 < num3) {
         System.out.println(" A Ordem Crescente é"+num2 );
         System.out.println(+num1);
         System.out.println(+ num3);
     }
     else if (num3 < num2 && num3 < num1 && num2 < num1) {
         System.out.println(" A Ordem Crescente é"+num3 );
         System.out.println(+num2);
         System.out.println(+ num1);
     }
     else{ System.out.println("Ocorreu um erro, você digitou numeros iguais");}
     }
     
   
 
 }