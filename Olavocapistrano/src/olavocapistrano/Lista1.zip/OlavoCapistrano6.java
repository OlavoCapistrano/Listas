/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo
 */
public class OlavoCapistrano6 {
    /*
    Questão 6: 
    Faça um programa em Java que calcule o aumento de salário para o corrente ano.   Se salário > 1000 o aumento é de 5%. Senão o aumento é de 7%. 
    
    */

public static void main(String[] args) {
    /* Resposta :
    */
   float salario, aumento = 0, salariototal; 
        Scanner dados =  new Scanner(System.in); 
       System.out.println("Digite o valor do seu Salário ");
        salario = dados.nextInt();
       
     if (salario > 1000) {
        aumento = (float) 0.05;
        salariototal = ((salario * aumento) + salario);
         
         System.out.println("O Aumento para o ano recorrente foi de 5%, o valor total é de :" + salariototal);
     }
     
     else if (salario < 1000) {
         aumento = (float) 0.07;
         salariototal = ((salario * aumento) + salario);
         System.out.println("O Aumento para o ano recorrente foi de 7% e o valor total é de :" + salariototal);
     }
     else System.out.println("Ocorreu um erro");
     
       
}

}