/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano10 {
    /*
    Questão 10 :
     Fazer um programa que resolva uma equação de segundo grau, realizando consistência dos valores do delta e do coeﬁciente "a".
    Caso o delta seja negativo, deve apenas ser impressa a mensagem: "Esta equação não possui raízes reais" 
    Caso o coeﬁciente "a" seja igual a zero, deve ser impressa a mensagem: "Esta não é uma equação de segundo grau" 
    e deve ser fornecido o valor da única raiz. Se o delta for maior que zero e "a" não for nulo,
    deverá ser impresso a mensagem "as raízes da equação: ax2 + bx + c = 0 são R1 = xxx e R2 = xxx"
    */


 public static void main(String[] args) {
    /* Resposta :
    */
     double a,b,c,delta,x1,x2;
     x1= 0;
     x2= 0;
 Scanner dados =  new Scanner(System.in); 
 
     System.out.println("Escreva o valor de A");
     a = dados.nextDouble();
     System.out.println("Escreva o Valor de B");
     b = dados.nextDouble();
     System.out.println("Escreva o Valor de C");
     c = dados.nextDouble();
     
     delta = (( b * b ) - ( 4 * a * c ));
     
     if ( delta < 0) {
     System.out.println("Esta equação não possui raízes reais");}
     else if ( a == 0) {
     System.out.println("Esta não é uma equação de segundo grau");
     }
     
     else if (delta > 0) {
         x1 = ( ( - b + ( Math.sqrt (delta) ) ) / ( 2 * a));
         x2 = ( ( - b -( Math.sqrt (delta) ) ) /( 2 *  a));
      
         System.out.println("x' equivale a : "+ x1);
         
         System.out.println("x'' equivale a : "+ x2);
     }
     else System.out.println("Delta Invalido");
}
 
}
