/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano1 {

    /** Questão Numero 1
     * Fazer um programa em Java que leia 4 números (A, B, C, D) e encontre o maior deles. Imprima uma mensagem dizendo qual deles é o maior e o valor do maior.
     * 

     */ 
    public static void main(String[] args) {
        /* Resposta :
        
        */
       Scanner dados =  new Scanner(System.in); 
       float valor1,valor2,valor3,valor4;
       
        System.out.println("Insira o valor do primeiro numero");
        valor1 = dados.nextFloat();
        
        System.out.println("Insira o valor do segundo numero");
        valor2 = dados.nextFloat();
        
        System.out.println("Insira o valor do terceiro numero");
        valor3 = dados.nextFloat();
        
        System.out.println("Insira o valor do quarto numero");
        valor4 = dados.nextFloat();
        
        if (valor1 > valor2 && valor1 > valor3 && valor1 > valor4) {
          
            System.out.println("O Valor do primeiro numero é o maior, o valor correspondente é :" + valor1);
        
    } 
        else if (valor2 > valor1 && valor2 > valor3 && valor2 > valor4) {
            
            System.out.println("O Valor do segundo numero é o maior, o valor correspondente é :" + valor2);
            
        }
        else if (valor3 > valor1 && valor3 > valor2 && valor3 > valor4) {
            
            System.out.println("O Valor do terceiro numero é o maior, o valor correspondente é :" + valor3);
        }
        else if (valor4 > valor1 && valor4 > valor3 && valor4 > valor2) {
           
            System.out.println("O Valor do quarto numero é o maior, o valor correspondente é :" + valor4);
    }
        else {System.out.println("Existem Numeros Iguais");}
    }

}
    
