/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano2 {
    /** Questão numero 2  
     * Faça um programa que receba a idade de uma pessoa e mostre na saída em qual categoria ela se encontra: 
           * 10-14 infantil  
          * 15-17 juvenil 
          * 18-25 adulto 
  
    */
    public static void main(String[] args) {
        /* Resposta :
        
        */
       Scanner dados =  new Scanner(System.in); 
int idade;

        System.out.println("Insira sua Idade : ");
        idade = dados.nextInt();
    
  if (idade>=10 && idade <=14){
      System.out.println("Você se encontra na categoria Infantil");
      }
  else if (idade>=15 && idade <=17){
      System.out.println("Você se encontra na categoria Juvenil");
      }
  else if (idade>=18 && idade <=25){
      System.out.println("Você se encontra na categoria Adulto");
      }
  else {System.out.println("Você não pertence a nenhuma das categorias citadas ");}

    
}

}