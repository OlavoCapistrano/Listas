/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano9 {
    /*
    Questão  9:
    Fazer um programa que: dada a altura e peso de uma pessoa, calcule seu índice de massa corporal.
    Fórmula: peso dividido por altura ao quadrado. 
    Faixas: <= 18,5 - abaixo do peso normal;
    > 18,5 e <= 25 - peso normal;
    > 2 e <=30 - peso acima do normal;
    acima de 30 - peso excessivo
    */
    
    public static void main(String[] args) {
    /* Resposta :
    */
     float altura, peso, imc;
     
 Scanner dados =  new Scanner(System.in); 
    
        System.out.println("Informe o valor correspondente ao seu peso");
        peso = dados.nextFloat();
        System.out.println("Informe o valor correspondente a sua altura");
        altura = dados.nextFloat();
        
     imc = peso/ (altura*altura);
     
 if (imc <= 18.5) {
     System.out.println("Abaixo do peso");
                  }
 else if (imc > 18.5 && imc <=25) {
     System.out.println("Peso normal");
 }  
 else if (imc > 25 && imc <=30) {
     System.out.println("Peso acima do normal");
 }
 else if (imc >30) {
     System.out.println("Peso Excessivo");
 }
 else System.out.println("Ocorreu um erro");
    }


}