/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano3 {
    
    /* Questao Numero 3
    Elabora um programa que ao receber um numero inteiro determine retorne se o mesmo é par ou impar. 
    
    */
    public static void main(String[] args) {
   int numero; 
   /* Resposta :
   
   */
        Scanner dados =  new Scanner(System.in); 
       
        System.out.println("Insira um Numero");
       numero = dados.nextInt();
if ((numero %2) == 0)
    System.out.println("Par");

else System.out.println("Impar"); }   

}