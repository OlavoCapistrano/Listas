/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano4 {
/* 
    Questão Numero 4
    Faça um programa que informe o mês de acordo com o número informado pelo usuário. (Exemplo: Entrada: 4. Saída: Abril)
    
   */
    public static void main(String[] args) {
   /* Resposta :
   */
   int mês; 
        Scanner dados =  new Scanner(System.in); 
        System.out.println("Digite O Numero Correspondente ao Mês :");
        mês = dados.nextInt();
        
        switch (mês){
            case 1: System.out.println("O Mês de numero 1 é Janeiro");break;
            case 2: System.out.println("O Mês de numero 2 é Fevereiro");break;
            case 3: System.out.println("O Mês de numero 3 é Março");break;
            case 4: System.out.println("O Mês de numero 4 é Abril");break;
            case 5: System.out.println("O Mês de numero 5 é Maio");break;
            case 6: System.out.println("O Mês de numero 6 é Junho");break;
            case 7: System.out.println("O Mês de numero 7 é Julho");break;
            case 8: System.out.println("O Mês de numero 8 é Agosto");break;
            case 9: System.out.println("O Mês de numero 9 é Setembro");break;
            case 10: System.out.println("O Mês de numero 10 é Outubro");break;
            case 11: System.out.println("O Mês de numero 11 é Novembro");break;
            case 12: System.out.println("O Mês de numero 12 é Dezembro");break;
            default : System.out.println("O Mês informado não existe");
                
        }
}
    
}
