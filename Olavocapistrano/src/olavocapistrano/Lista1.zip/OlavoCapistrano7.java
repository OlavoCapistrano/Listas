/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olavocapistrano;

import java.util.Scanner;

/**
 *
 * @author Olavo Capistrano
 */
public class OlavoCapistrano7 {
    /* 
        Preparar um algoritmo e um programa em Java para ler os comprimentos dos três lados de um triângulo (S1, S2, e S3)
        e determinar que tipo de triângulo temos, com base nos seguintes casos.
        Sejam A o maior dos lados de S1, S2, e S3 e B e C os outros dois lados.  
        Então: 
    Se  A ≥ B + C nenhum triângulo é formado 
    Se A2 = B2 + C2 um triângulo retângulo é formado,
    Se A2 > B2 + C2 um triângulo obtusângulo é formado  
    Se A2 < B2 + C2 um triângulo acutângulo é formado 
    
    */
    
    public static void main(String[] args) {
    /* Resposta :
    */
      
      int valor1, valor2, valor3;
      int A = 0, B = 0, C = 0;
        Scanner dados =  new Scanner(System.in); 
        System.out.println("Insira o comprimento do primeiro lado do Triangulo");
        valor1 = dados.nextInt();
        System.out.println("Insira o comprimento do segundo lado do Triangulo");
        valor2 = dados.nextInt();
        System.out.println("Insira o Comprimento do Terceiro Lado do Triangulo");
        valor3 = dados.nextInt();
        
        if (valor1 > valor2 && valor1 > valor3 && valor2 > valor3) {
          
        A = (int) valor1;
        B = (int) valor2;
        C = (int) valor3; 
        System.out.println("O Valor de A é : " + A);
        
        System.out.println("O Valor de B é : " + B);
        
        System.out.println("O Valor de C é : " + C);
        
        }
        
        else if (valor2 > valor1 && valor2 > valor3 && valor1 > valor3) {
          
        B = (int) valor1;
        A = (int) valor2;
        C = (int) valor3; 
        System.out.println("O Valor de A é : " + A);
        
        System.out.println("O Valor de B é : " + B);
        
        System.out.println("O Valor de C é : " + C);
    
        }
        
        else if (valor3 > valor2 && valor3 > valor1 && valor2 > valor1) {
          
        C = (int) valor1;
        B = (int) valor2;
        A = (int) valor3; 
        System.out.println("O Valor de A é : " + A);
        
        System.out.println("O Valor de B é : " + B);
        
        System.out.println("O Valor de C é : " + C);
    
        }
        else if (valor1 > valor2 && valor1 > valor3 && valor3 > valor2) {
          
        A = (int) valor1;
        C = (int) valor2;
        B = (int) valor3; 
        System.out.println("O Valor de A é : " + A);
        
        System.out.println("O Valor de B é : " + B);
        
        System.out.println("O Valor de C é : " + C);
    
        }
        else if (valor2 > valor1 && valor2 > valor3 && valor3 > valor1) {
          
        C = (int) valor1;
        A = (int) valor2;
        B = (int) valor3; 
        System.out.println("O Valor de A é : " + A);
        
        System.out.println("O Valor de B é : " + B);
        
        System.out.println("O Valor de C é : " + C);
    
        }
        else if (valor3 > valor2 && valor3 > valor1 && valor1 > valor2) {
          
        B = (int) valor1;
        C = (int) valor2;
        A = (int) valor3; 
        System.out.println("O Valor de A é : " + A);
        
        System.out.println("O Valor de B é : " + B);
        
        System.out.println("O Valor de C é : " + C);
        }
        if ( A >= B + C) {
        System.out.println(" O Triângulo não é formado");
    }
        else if ((A*A) == (B*B) + (C*C)) {
            System.out.println("Um Triângulo Retângulo é formado");
        }
        else if ((A*A) > (B*B)+ (C*C)) {
            System.out.println("Um Triângulo Obtusângulo é formado");
        }
        else if ((A*A) < (B*B) * (C*C)) {
            System.out.println("Um Triângulo Acutângulo é formado ");
        }
    
    }
}

